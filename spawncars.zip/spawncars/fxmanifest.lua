fx_version 'cerulean'
game 'gta5'

author 'willpsdk'
description 'simple car spawner for the console / text chat'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'
