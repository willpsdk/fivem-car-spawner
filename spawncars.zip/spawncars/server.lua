print("[SERVER] Loaded")

RegisterCommand("car", function(source, args)
    local model = args[1]

    if not model then
        -- Optional message if nothing is entered
        TriggerClientEvent('chat:addMessage', source, {
            args = {"^1Usage:", "/car [vehicleName]"}
        })
        return
    end

    TriggerClientEvent("spawnVehicle", source, model)
end)
