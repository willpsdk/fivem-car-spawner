print("[CLIENT] Loaded")

local lastVehicle = nil

RegisterNetEvent("spawnVehicle")
AddEventHandler("spawnVehicle", function(modelName)
    local modelHash = GetHashKey(modelName)

    if not IsModelInCdimage(modelHash) then
        return -- Silently fail if invalid model
    end

    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Wait(100)
    end

    -- Delete old vehicle
    if lastVehicle and DoesEntityExist(lastVehicle) then
        DeleteVehicle(lastVehicle)
    end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)

    local vehicle = CreateVehicle(modelHash, coords.x, coords.y, coords.z + 1.0, heading, true, false)
    TaskWarpPedIntoVehicle(ped, vehicle, -1)

    lastVehicle = vehicle

    SetModelAsNoLongerNeeded(modelHash)
end)
